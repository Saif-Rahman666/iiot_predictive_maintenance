import 'dart:async';
import '../models/sensor_data.dart';

class SensorDataService {
  final _controller = StreamController<SensorData>.broadcast();

  Stream<SensorData> get stream => _controller.stream;

  /// Temporary simulated update (will be replaced by MQTT)
  void start() {
    int tick = 0;

    Timer.periodic(const Duration(seconds: 2), (timer) {
      tick++;

      final data = SensorData(
        timestamp: DateTime.now(),
        temperature: 24 + (tick % 5),
        proximity: 300.0 + tick,
        light: 120 + (tick % 20),
        rul: (100 - tick).clamp(0, 100).toDouble(),
        anomaly: tick > 70,
      );

      /// TODO: Replace simulation with MQTT subscription
/// Expected payload:
/// {
///   "temperature": double,
///   "proximity": double,
///   "light": double,
///   "rul": double,
///   "anomaly": bool
/// }

      _controller.add(data);
    });
  }

  void dispose() {
    _controller.close();
  }
}
